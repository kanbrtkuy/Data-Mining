1. file_path in freq_pattern_mining() is used to record the input file path of test_input.txt, you can change the file path by edit file_path
2. output_path in freq_pattern_mining() is used to record the output file path of res.txt, the result will be recorded in res.txt after running the program, you can change the file path by edit output_path
